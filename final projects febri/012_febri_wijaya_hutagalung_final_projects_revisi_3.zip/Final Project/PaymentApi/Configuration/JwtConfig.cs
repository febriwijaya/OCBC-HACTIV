namespace PaymentApi.Configuration {
    public class JwtConfig {
        public string Secret { get; set; }
    }
}